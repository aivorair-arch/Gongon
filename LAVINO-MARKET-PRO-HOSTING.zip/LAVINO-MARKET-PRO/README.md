# LAVINO MARKET PRO

نسخه مستقل برای نصب روی دامنه و هاست/VPS شخصی.

## پیش‌نیاز
- PHP 8.2+
- MySQL/MariaDB
- PDO MySQL
- mbstring
- XML
- cURL
- Composer

## نصب روی VPS
1. فایل ZIP را Extract کنید.
2. `composer install --no-dev --optimize-autoloader`
3. Document Root را روی `public/` قرار دهید.
4. دسترسی نوشتن `storage/` و `bootstrap/cache/` را تنظیم کنید.
5. دامنه را به سرور وصل و SSL را فعال کنید.
6. آدرس `/install` را باز کنید و مشخصات دیتابیس و مدیر را وارد کنید.
7. پس از نصب `installed.lock` ایجاد می‌شود.

## نصب روی cPanel
PHP 8.2+ و Extensionهای PDO MySQL، mbstring، XML و cURL را فعال کنید.
فایل را Extract کنید. ترجیحاً Document Root دامنه روی پوشه `public` باشد.
اگر Composer روی هاست فعال نیست، dependencies را قبل از Upload روی سیستم دیگری با
`composer install --no-dev --optimize-autoloader`
بسازید و پوشه `vendor` را نیز همراه پروژه Upload کنید.

## Queue
برای هاست اشتراکی، Queue از database استفاده می‌کند. یک Cron Job در cPanel بسازید:
`* * * * * php /home/USER/path/to/artisan schedule:run >> /dev/null 2>&1`

برای VPS می‌توانید worker دائمی Laravel اجرا کنید.

## نکته
Crawler فقط برای سایت‌هایی استفاده شود که اجازه دسترسی/خزش می‌دهند و robots.txt و rate limit رعایت شود.
این نسخه هسته قابل نصب پروژه است؛ برای مقیاس Enterprise واقعی، Search جداگانه (OpenSearch/Elastic)، object storage، monitoring و workerهای مستقل باید در مرحله مقیاس‌گذاری اضافه شوند.
