# راهنمای هاست شخصی

## cPanel
- یک MySQL Database و User بسازید.
- PHP را روی 8.2 یا بالاتر بگذارید.
- Extensionهای pdo_mysql، mbstring، xml و curl را فعال کنید.
- فایل ZIP را در home یا public_html آپلود و Extract کنید.
- بهترین حالت: دامنه را روی `LAVINO-MARKET-PRO/public` تنظیم کنید.
- اگر امکان تغییر Document Root ندارید، با پشتیبانی هاست درباره Laravel Document Root هماهنگ کنید.
- Cron را هر دقیقه روی `php /home/USER/LAVINO-MARKET-PRO/artisan schedule:run` تنظیم کنید.
- SSL را فعال کنید.
- `/install` را باز کنید.

## VPS
Nginx را طوری تنظیم کنید که root روی `.../public` باشد و تمام درخواست‌ها به `index.php` بروند.
PHP-FPM 8.2+ و MySQL را نصب کنید.
