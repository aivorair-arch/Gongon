<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
 public function up(): void {
  Schema::create('users',function(Blueprint $t){
   $t->id();$t->string('name');$t->string('email')->unique();$t->string('password');$t->string('role')->default('user');$t->timestamps();
  });
  Schema::create('stores',function(Blueprint $t){
   $t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->string('name');$t->string('domain')->unique();$t->string('logo')->nullable();$t->boolean('is_verified')->default(false);$t->timestamps();
  });
  Schema::create('products',function(Blueprint $t){
   $t->id();$t->string('title');$t->string('model')->nullable();$t->string('brand')->nullable();$t->string('sku')->nullable();
   $t->string('gtin')->nullable();$t->text('description')->nullable();$t->text('search_text')->nullable();$t->string('image')->nullable();
   $t->boolean('is_master')->default(true);$t->foreignId('master_product_id')->nullable()->constrained('products')->nullOnDelete();$t->timestamps();
   $t->index(['brand','model']);$t->index('sku');$t->index('gtin');
  });
  DB::statement('ALTER TABLE products ADD FULLTEXT search_index (title,brand,model,search_text)');
  Schema::create('offers',function(Blueprint $t){
   $t->id();$t->foreignId('product_id')->constrained()->cascadeOnDelete();$t->foreignId('store_id')->constrained()->cascadeOnDelete();
   $t->unsignedBigInteger('price');$t->unsignedBigInteger('old_price')->nullable();$t->boolean('in_stock')->default(true);$t->text('url');
   $t->decimal('match_score',5,2)->default(100);$t->timestamp('last_checked_at')->nullable();$t->timestamps();
   $t->index('price');$t->unique(['product_id','store_id']);
  });
  Schema::create('price_histories',function(Blueprint $t){
   $t->id();$t->foreignId('offer_id')->constrained()->cascadeOnDelete();$t->unsignedBigInteger('price');$t->date('recorded_date');$t->index(['offer_id','recorded_date']);
  });
  Schema::create('jobs',function(Blueprint $t){
   $t->bigIncrements('id');$t->string('queue')->index();$t->longText('payload');$t->unsignedTinyInteger('attempts');
   $t->unsignedInteger('reserved_at')->nullable();$t->unsignedInteger('available_at');$t->unsignedInteger('created_at');
  });
 }
 public function down(): void {
  Schema::dropIfExists('jobs');Schema::dropIfExists('price_histories');Schema::dropIfExists('offers');Schema::dropIfExists('products');Schema::dropIfExists('stores');Schema::dropIfExists('users');
 }
};