<?php
namespace App\Jobs;
use App\Models\Store;
use App\Services\CrawlerService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
class CrawlStoreJob implements ShouldQueue {
 use Dispatchable,InteractsWithQueue,Queueable,SerializesModels;
 public $tries=3;public $timeout=120;
 public function __construct(public Store $store){}
 public function handle(CrawlerService $crawler){$crawler->crawlStore($this->store);}
}