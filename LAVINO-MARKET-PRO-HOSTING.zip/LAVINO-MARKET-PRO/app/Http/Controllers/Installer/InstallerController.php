<?php
namespace App\Http\Controllers\Installer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class InstallerController extends Controller
{
    public function index()
    {
        if (File::exists(base_path('installed.lock'))) return redirect('/');
        $requirements = [
            'PHP Version >= 8.2' => version_compare(PHP_VERSION, '8.2.0', '>='),
            'PDO Extension' => extension_loaded('pdo'),
            'MySQL Driver' => extension_loaded('pdo_mysql'),
            'MBString Extension' => extension_loaded('mbstring'),
            'XML Extension' => extension_loaded('xml'),
            'CURL Extension' => extension_loaded('curl'),
        ];
        return view('installer.index', ['requirements'=>$requirements,'failed'=>array_filter($requirements,fn($v)=>!$v)]);
    }

    public function install(Request $request)
    {
        if (File::exists(base_path('installed.lock'))) return redirect('/');
        $data = $request->validate([
            'site_url'=>'required|url','db_host'=>'required','db_name'=>'required',
            'db_user'=>'required','db_pass'=>'nullable','admin_email'=>'required|email',
            'admin_password'=>'required|min:8'
        ]);

        $env = "APP_NAME=\"LAVINO MARKET PRO\"\nAPP_ENV=production\nAPP_KEY=\nAPP_DEBUG=false\nAPP_URL={$data['site_url']}\n"
             ."LOG_CHANNEL=stack\nLOG_LEVEL=warning\nDB_CONNECTION=mysql\nDB_HOST={$data['db_host']}\nDB_PORT=3306\n"
             ."DB_DATABASE={$data['db_name']}\nDB_USERNAME={$data['db_user']}\nDB_PASSWORD={$data['db_pass']}\n"
             ."CACHE_STORE=file\nSESSION_DRIVER=file\nQUEUE_CONNECTION=database\nAI_ENABLED=false\nAI_API_KEY=\nAI_BASE_URL=\nMAIL_MAILER=log\n";
        File::put(base_path('.env'), $env);
        Artisan::call('config:clear');

        try {
            DB::connection()->getPdo();
            Artisan::call('key:generate',['--force'=>true]);
            Artisan::call('config:clear');
            Artisan::call('migrate',['--force'=>true]);
            User::create([
                'name'=>'مدیر سیستم','email'=>$data['admin_email'],
                'password'=>Hash::make($data['admin_password']),'role'=>'admin'
            ]);
            File::put(base_path('installed.lock'), now()->toDateTimeString());
            return redirect('/')->with('success','نصب با موفقیت انجام شد.');
        } catch (\Throwable $e) {
            return back()->withErrors(['install'=>'خطا در نصب: '.$e->getMessage()])->withInput();
        }
    }
}
