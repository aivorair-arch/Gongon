<?php
namespace App\Services;
use App\Models\Product;
use App\Traits\PersianSearchable;

class ProductMatchingService {
 use PersianSearchable;
 public function findOrCreateMaster(array $data): Product {
  $title=self::normalizePersian($data['title']??'');
  $brand=self::normalizePersian($data['brand']??'');
  $model=self::normalizePersian($data['model']??'');
  $sku=$data['sku']??null;$gtin=$data['gtin']??null;
  if($sku && ($p=Product::where('sku',$sku)->where('is_master',true)->first())) return $p;
  if($gtin && ($p=Product::where('gtin',$gtin)->where('is_master',true)->first())) return $p;
  $candidates=Product::where('is_master',true)->where(function($q)use($brand,$model){
   if($brand)$q->orWhere('brand','like',"%$brand%");
   if($model)$q->orWhere('model','like',"%$model%");
  })->limit(30)->get(['id','title','brand','model']);
  foreach($candidates as $p) if($this->score($title,$brand,$model,$p)>=85)return $p;
  return Product::create(['title'=>$data['title'],'brand'=>$brand,'model'=>$model,'sku'=>$sku,'gtin'=>$gtin,
   'description'=>$data['description']??null,'image'=>$data['image']??null,'is_master'=>true,
   'search_text'=>self::normalizePersian(($data['title']??'').' '.$brand.' '.$model)]);
 }
 private function score($title,$brand,$model,Product $p):float{
  $score=0;
  $score += $this->sim($title,self::normalizePersian($p->title))*0.50;
  $score += $this->sim($brand,self::normalizePersian($p->brand??''))*0.25;
  $score += $this->sim($model,self::normalizePersian($p->model??''))*0.25;
  return round($score,2);
 }
 private function sim($a,$b):float{
  if($a===''||$b==='')return 0;
  if($a===$b)return 100;
  similar_text($a,$b,$pct); return $pct;
 }
}