<?php
namespace App\Services;
use App\Models\Store;
use App\Models\Offer;
use App\Models\PriceHistory;
use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler as DomCrawler;
use Illuminate\Support\Facades\Log;

class CrawlerService {
 public function __construct(private ProductMatchingService $matcher){}
 public function crawlStore(Store $store):void {
  $client=new Client(['timeout'=>15,'http_errors'=>false,'headers'=>['User-Agent'=>'LavinoMarketBot/1.0']]);
  try {
   $res=$client->get(rtrim($store->domain,'/').'/sitemap.xml');
   if($res->getStatusCode()>=400)return;
   $dom=new DomCrawler((string)$res->getBody());
   $urls=[];
   $dom->filter('loc')->each(function($n)use(&$urls){$urls[]=$n->text();});
   foreach(array_slice($urls,0,1000) as $url){$this->process($client,$store,$url);usleep(1000000);}
  }catch(\Throwable $e){Log::warning('Crawler init failed: '.$e->getMessage());}
 }
 private function process(Client $client,Store $store,string $url):void {
  try{
   $res=$client->get($url);if($res->getStatusCode()>=400)return;
   $dom=new DomCrawler((string)$res->getBody());$data=null;
   $dom->filter('script[type="application/ld+json"]')->each(function($n)use(&$data){
    $x=json_decode($n->text(),true);
    if(isset($x['@type'])&&(($x['@type']==='Product')||(is_array($x['@type'])&&in_array('Product',$x['@type']))))$data=$x;
   });
   if(!$data)return;
   $brand=is_array($data['brand']??null)?($data['brand']['name']??''):($data['brand']??'');
   $offers=$data['offers']??[];$price=(int)($offers['price']??0);
   if(($offers['priceCurrency']??'')==='IRR')$price=(int)round($price/10);
   if($price<=0)return;
   $product=$this->matcher->findOrCreateMaster([
    'title'=>$data['name']??'محصول بدون نام','brand'=>$brand,'model'=>$data['model']??'',
    'sku'=>$data['sku']??null,'gtin'=>$data['gtin']??($data['mpn']??null),
    'description'=>$data['description']??null,
    'image'=>is_array($data['image']??null)?($data['image'][0]??null):($data['image']??null)
   ]);
   $offer=Offer::updateOrCreate(['product_id'=>$product->id,'store_id'=>$store->id],[
    'price'=>$price,'url'=>$url,'in_stock'=>str_contains(strtolower($offers['availability']??''),'instock'),
    'last_checked_at'=>now()
   ]);
   $last=PriceHistory::where('offer_id',$offer->id)->latest('recorded_date')->first();
   if(!$last||$last->price!==$price)PriceHistory::create(['offer_id'=>$offer->id,'price'=>$price,'recorded_date'=>now()->toDateString()]);
  }catch(\Throwable $e){Log::warning('Crawler page failed: '.$url);}
 }
}