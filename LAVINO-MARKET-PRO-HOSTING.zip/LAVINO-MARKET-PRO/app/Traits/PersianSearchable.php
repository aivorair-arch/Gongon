<?php
namespace App\Traits;

trait PersianSearchable
{
    public static function normalizePersian(string $text): string
    {
        $text = str_replace(['ي','ك','ة','أ','إ','آ','ؤ','ئ'], ['ی','ک','ه','ا','ا','ا','و','ی'], $text);
        $text = preg_replace('/[\x{064B}-\x{0652}\x{0670}\x{0640}]/u','',$text);
        $text = str_replace("\u{200C}",' ',$text);
        $text = preg_replace('/[^\p{L}\p{N}\s]/u',' ',$text);
        return trim(preg_replace('/\s+/u',' ',$text));
    }

    public function scopeSmartSearch($query,string $term)
    {
        $words = array_filter(explode(' ',self::normalizePersian($term)),fn($w)=>mb_strlen($w,'UTF-8')>=2);
        if (!$words) return $query;
        $fts = '+'.implode('* +',$words).'*';
        return $query->whereRaw(
            'MATCH(title,brand,model,search_text) AGAINST(? IN BOOLEAN MODE)',[$fts]
        )->orderByRaw(
            'MATCH(title,brand,model,search_text) AGAINST(? IN BOOLEAN MODE) DESC',[$fts]
        );
    }
}
