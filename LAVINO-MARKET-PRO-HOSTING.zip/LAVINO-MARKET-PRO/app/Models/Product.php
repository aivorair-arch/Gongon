<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Traits\PersianSearchable;
class Product extends Model {
 use PersianSearchable;
 protected $fillable=['title','model','brand','sku','gtin','description','search_text','image','is_master','master_product_id'];
}