<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Offer extends Model {
 protected $fillable=['product_id','store_id','price','old_price','in_stock','url','match_score','last_checked_at'];
 protected $casts=['in_stock'=>'boolean','last_checked_at'=>'datetime'];
}