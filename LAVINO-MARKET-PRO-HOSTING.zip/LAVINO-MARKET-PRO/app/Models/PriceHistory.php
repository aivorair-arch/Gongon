<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class PriceHistory extends Model {
 public $timestamps=false;
 protected $fillable=['offer_id','price','recorded_date'];
 protected $casts=['recorded_date'=>'date'];
}