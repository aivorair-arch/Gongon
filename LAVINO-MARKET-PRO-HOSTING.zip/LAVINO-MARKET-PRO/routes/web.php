<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Installer\InstallerController;

Route::get('/install', [InstallerController::class, 'index'])->name('installer.index');
Route::post('/install', [InstallerController::class, 'install'])->name('installer.install');

Route::get('/', function () {
    return view('home');
});
