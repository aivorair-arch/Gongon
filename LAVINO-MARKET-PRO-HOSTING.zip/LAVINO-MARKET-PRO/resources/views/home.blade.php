<!doctype html>
<html lang="fa" dir="rtl">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LAVINO MARKET PRO</title>
<style>
body{font-family:tahoma;margin:0;background:#f6f7f9;color:#111827}
header{background:#111827;color:#fff;padding:24px;text-align:center}
main{max-width:1100px;margin:35px auto;padding:0 18px}
.search{background:white;padding:25px;border-radius:18px;text-align:center;box-shadow:0 8px 30px #0001}
input{width:70%;padding:14px;border:1px solid #ddd;border-radius:10px}
button{padding:14px 20px;border:0;border-radius:10px;background:#111827;color:#fff}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:15px;margin-top:20px}
.card{background:#fff;padding:22px;border-radius:16px}
</style></head>
<body>
<header><h1>LAVINO MARKET PRO</h1><p>موتور جستجو و مقایسه قیمت</p></header>
<main>
<section class="search"><h2>🔎 دنبال چه محصولی هستید؟</h2>
<form><input name="q" placeholder="مثلاً تلویزیون سامسونگ 55 اینچ"><button>جستجو</button></form></section>
<div class="grid"><div class="card">💰 مقایسه قیمت</div><div class="card">📊 تاریخچه قیمت</div><div class="card">🤖 دستیار خرید AI</div><div class="card">🏪 فروشگاه‌ها</div></div>
</main></body></html>
