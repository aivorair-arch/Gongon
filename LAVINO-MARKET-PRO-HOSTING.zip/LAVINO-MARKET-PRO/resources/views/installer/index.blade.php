<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>نصب LAVINO MARKET PRO</title>
<style>
body{font-family:tahoma,sans-serif;background:#f5f7fb;margin:0;padding:30px}
.box{max-width:720px;margin:auto;background:#fff;padding:28px;border-radius:18px;box-shadow:0 10px 35px #0001}
h1{margin-top:0}.ok{color:#16803c}.bad{color:#b42318}
input{width:100%;padding:12px;margin:7px 0 14px;box-sizing:border-box;border:1px solid #ddd;border-radius:9px}
button{width:100%;padding:14px;border:0;border-radius:10px;background:#111827;color:white;font-size:16px}
small{color:#666}
</style>
</head>
<body>
<div class="box">
<h1>🚀 نصب LAVINO MARKET PRO</h1>
<p>پیش‌نیازهای سرور:</p>
<ul>
@foreach($requirements as $name=>$ok)
<li class="{{ $ok ? 'ok':'bad' }}">{{ $ok ? '✓':'✗' }} {{ $name }}</li>
@endforeach
</ul>
@if($failed)
<p class="bad">ابتدا پیش‌نیازهای علامت‌خورده را روی هاست فعال کنید.</p>
@else
<form method="post" action="{{ route('installer.install') }}">
@csrf
<label>آدرس سایت</label><input name="site_url" value="{{ request()->getScheme().'://'.request()->getHttpHost() }}" required>
<label>DB Host</label><input name="db_host" value="127.0.0.1" required>
<label>DB Name</label><input name="db_name" required>
<label>DB Username</label><input name="db_user" required>
<label>DB Password</label><input type="password" name="db_pass">
<label>ایمیل مدیر</label><input type="email" name="admin_email" required>
<label>رمز مدیر (حداقل ۸ کاراکتر)</label><input type="password" name="admin_password" minlength="8" required>
<button>نصب و ساخت دیتابیس</button>
</form>
@endif
<small>پس از نصب، فایل installed.lock ساخته می‌شود و نصب مجدد قفل خواهد شد.</small>
</div>
</body>
</html>
